# Database SimuLearn

This document represents completion of the AWS Database SimuLearn module.

## Skills Covered
- Database fundamentals
- Relational and non-relational databases
- AWS-managed database concepts
