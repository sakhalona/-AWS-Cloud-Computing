# Security SimuLearn

This document represents completion of the AWS Security SimuLearn module.

## Skills Covered
- Shared Responsibility Model
- Cloud security fundamentals
- Identity and access concepts
