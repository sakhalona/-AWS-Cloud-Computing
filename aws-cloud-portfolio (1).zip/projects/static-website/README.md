# Static Website Project

## Description
This project demonstrates hosting a static website using AWS services.

## Concepts Demonstrated
- Static website hosting
- Cloud architecture basics
- Deployment principles
